/*
---------------------------------------------------------------------------------
 6. Destructing
---------------------------------------------------------------------------------
This is one of the powerful feature in ES6, where in instead of adding a single value
to a variable from an array, we can do it all by once.

*/

//Starter

let array = [10001,'naveen','TechLead'];
let id = array[0];
let myName = array[1];
let designation = array[2];



// Best usage is to exchange the value btw a & b


// This is even works for Objects

