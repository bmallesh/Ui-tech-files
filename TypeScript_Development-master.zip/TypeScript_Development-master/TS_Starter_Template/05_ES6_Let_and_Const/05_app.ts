/*
---------------------------------------------------------------------------------
 3. Let & Const
---------------------------------------------------------------------------------
 This 'let' is an ES6 Feature to declare variables like 'var' in javascript.

*/

//problem

for(var i = 0; i < 10; i++){
    var myName = "naveen";
}

console.log(myName);

