// Create a simple function to add two numbers



// Create the same add function with first number as 'any' type


// Function Overloading in TypeScript , findMax of 1 , 2 , 3 numbers


// Create an Employee function and get an Employee Object
