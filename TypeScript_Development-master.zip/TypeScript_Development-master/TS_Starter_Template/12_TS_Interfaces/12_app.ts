// Create a Student Interface , and printStudent function

