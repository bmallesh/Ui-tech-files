/*
---------------------------------------------------------------------------------
 4. for...of loop
---------------------------------------------------------------------------------
 Before this, we were using "for..in"

*/

//Starter

let myArray = ['html','javascript','css','bootstrap'];

for(let index in myArray){
    let value = myArray[index];
    console.log(value);
}

