

// Hello World App

/*

DataTypes in TypeScript

1.Boolean
2.Number
3.String
4.array[]
5.any

 */

