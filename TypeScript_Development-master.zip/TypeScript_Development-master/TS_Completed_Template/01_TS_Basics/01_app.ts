

// Hello World App

function greet(name:string){
    let output = "Good Morning " + name;
    console.log(output);
    document.getElementById('display').innerHTML = output;
}

greet('Naveen');

/*

DataTypes in TypeScript

1.Boolean
2.Number
3.String
4.array[]
5.any

 */

