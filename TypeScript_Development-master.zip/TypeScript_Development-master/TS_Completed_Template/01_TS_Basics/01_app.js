// Hello World App
function greet(name) {
    var output = "Good Morning " + name;
    console.log(output);
    document.getreet('Naveen');ElementById('display').innerHTML = output;
}
g
/*

DataTypes in TypeScript

1.Boolean
2.Number
3.String
4.array[]
5.any

 */
